const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/tudo_server", {
    useNewUrlParser: true,
    useUnifiedTopology: true
})

const User = mongoose.model('User', {
    username: String,
    name: String,
    password: String

})
const Tudodata = mongoose.model('Tudodata', {
    username:String,
    name: String,
    description: String

})
module.exports = {
   User,
   Tudodata
  
}