const db = require('./db');

let currentUser;

const register = ( username, name, password) => {

    return db.User.findOne({
        username
    }).then(user => {
        console.log(user);
        if (user) {
            return {
                status: false,
                statusCode: 422,
                message: "user exists"
            }

        } else {
            const newUser = new db.User({
                
                username,
                name,
                password

            });
            newUser.save();
            return {
                status: true,
                statusCode: 200,
                message: "Registration successful"
            }
        }

    })
}



const addTodo = (req,name,description) => {
    username=req.session.currentUser.username;
    return db.Tudodata.findOne({
        description
    }).then(user => {
        console.log(user);
        if (user) {
            return {
                status: false,
                statusCode: 422,
                message: "user exists"
            }

        } else {
            const newUser = new db.Tudodata({
                
                username,
                name,
                description

            });
            newUser.save();
            return {
                status: true,
                statusCode: 200,
                message: "data successful"
                
            }
        }

    })
}
  
const editTodo=(req,id,name,description) => {
   
    return  db.Tudodata.updateOne({_id:id},{$set:{name:name,
    description:description}
    }).then(tudo => {
        if (!id) {
            return {
                status: false,
                statusCode: 422,
                message: "There is no data"
            }

        }
        else{
             return {
                status: true,
                statusCode: 200,
                message: "success"
            }
        }
    })
}



const getTodos = (req) => {
    
    return db.Tudodata.find({

       
        
    }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: "Datas",
            element:user
        }

    })
    



}



const getTodo = (id) => {
    
    return db.Tudodata.find({
        
        _id:id
       
        
    }).then(user => {
       console.log(user);
        return {
            status: true,
            statusCode: 200,
            message: "Datas get",
            element:user
        }

    })
    



}

const login = (req,username, password) => {

    return db.User.findOne({

        username,
        password
    }).then(user => {
        if (user) {
            req.session.currentUser = user;
             

            return {
                status: true,
                statusCode: 200,
                message: "login Successful",
                name: user.username,
                id: user._id

            }
        }
        return {
            status: false,
            statusCode: 422,
            message: "Invalid Login"
        }

    })

}


module.exports = {
    register,
    login,
    addTodo,
    getTodos,
    getTodo,
    editTodo
}