const express = require("express");
const dataservice = require("./dataservice/dataservice.js");
const session = require("express-session");
const cors = require('cors');
const { json } = require("express");
const app = express();
app.use(express.json());

app.use(session({
    secret: 'randomsecurestring',
    resave: false,
    saveUninitialized: false
}))

app.use(cors({
    origin: 'http://localhost:4200',
    credentials: true
})) 

const authMiddleware = (req, res, next) => {
    if (!req.session.currentUser) {
        return res.json({
            status: false,
            statusCode: 401,
            message: "please login"
        })
    } else {
        next()
    }
}

app.post("/", (req, res) => {
    res.status(200).send("post method");
})


app.get("/", (req, res) => {
    res.status(200).send("get method");
})



app.post("/addTodo",authMiddleware, (req, res) => {
    
    console.log(req.body);
    dataservice.addTodo(
            req,
            req.body.name,
            req.body.description
        )
        .then(result => {
            res.status(result.statusCode).json(result)
        })
        // console.log(res.send(result.message));
});

app.put("/editTodo/:id", authMiddleware, (req, res) => {
    
    console.log(req.body);
    dataservice.editTodo(
            req,
            req.params.id,
            req.body.name,
            req.body.description
        )
        .then(result => {
            res.status(result.statusCode).json(result)
        })
        // console.log(res.send(result.message));
});


app.get("/getTodos", (req, res) => {
   
    dataservice.getTodos()
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});

app.get("/getTodo/:id", (req, res) => {
   
    dataservice.getTodo(req.params.id)
     .then(result => {
            res.status(result.statusCode).json(result)
        })
});

app.post('/register', (req, res) => {
    console.log(req.body);
    dataservice.register(req.body.username, req.body.name, req.body.password)

    .then(result => {
            res.status(result.statusCode).json(result)
        })
        //console.log(res.status(result.statusCode).json(result));
})
app.post("/login", (req, res) => {
    console.log(req.body);
    dataservice.login(
            req,
            req.body.username,
            req.body.password
        )
        .then(result => {

            res.status(result.statusCode).json(result)
        })
        //console.log(res.send(result.message));
});











app.listen(7000, () => {
    console.log("app started at port 7000");
});

